import json

with open('./playground/our_ur5/berkeley_our_ur5_training_bowl.json', 'r') as f:
    data = json.load(f)

post_processed_data = []
for sample in data:
    if sample["conversations"][1]["value"] != "0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0":
        post_processed_data.append(sample)

with open('./playground/our_ur5/berkeley_our_ur5_training_post_processed_bowl.json', 'w', encoding='utf-8') as f:
    json.dump(post_processed_data, f, indent=4)